import { chromium } from 'playwright';
import { spawn } from 'child_process';

const WAIT_TIME = 5000; // Time to wait for server to start

async function runTests() {
  console.log('Starting dev server...');
  const server = spawn('npm', ['run', 'dev'], {
    stdio: 'pipe',
    shell: true,
  });

  server.stdout.on('data', (data) => {
    console.log(`Server: ${data}`);
  });

  server.stderr.on('data', (data) => {
    console.error(`Server Error: ${data}`);
  });

  // Give server time to start
  await new Promise(resolve => setTimeout(resolve, WAIT_TIME));

  let browser;
  try {
    console.log('Launching browser...');
    browser = await chromium.launch();
    const context = await browser.newContext();
    const page = await context.newPage();

    console.log('Navigating to app...');
    // Assuming Vite defaults to 5173
    await page.goto('http://localhost:5173');

    // Wait for content to load
    await page.waitForTimeout(2000);

    // Basic structural checks
    console.log('Checking main UI elements...');
    
    // Check if main heading exists
    const hasHeader = await page.locator('header').isVisible();
    console.log(`Header visible: ${hasHeader}`);
    
    // Check if content container exists
    const hasMainContent = await page.locator('main').isVisible();
    console.log(`Main content visible: ${hasMainContent}`);

    // Check if error overlays exist (we want this to be false)
    const hasViteError = await page.locator('vite-error-overlay').isVisible().catch(() => false);
    if (hasViteError) {
      console.error('CRITICAL: Vite error overlay detected!');
      process.exit(1);
    }

    console.log('Taking screenshot...');
    await page.screenshot({ path: 'ui_test_screenshot.png' });

    console.log('Tests completed successfully.');
  } catch (error) {
    console.error('Test failed:', error);
    process.exit(1);
  } finally {
    if (browser) {
      await browser.close();
    }
    server.kill();
    process.exit(0);
  }
}

runTests();
